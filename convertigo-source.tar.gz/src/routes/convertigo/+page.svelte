<script lang="ts">
  import { onMount } from 'svelte';
  import AudioButton from './components/AudioButton.svelte';
  import ConversionTable from './components/ConversionTable.svelte';
  import HelpPanel from './components/HelpPanel.svelte';
  import { belts, content, getContent } from './data/convertigo';
  import { validateExercise } from './engines/correctionEngine';
  import { levelFromXp, progressPercent, xpForAnswer } from './engines/progressionEngine';
  import { beltKey, loadProgress, saveProgress } from './services/storage';
  import type { BeltId, Exercise } from './types/exercise';
  import type { PlayerProgress } from './types/progress';

  type Screen = 'map' | 'zone' | 'lesson' | 'flash' | 'practice' | 'boss' | 'final';

  let ready = false;
  let screen: Screen = 'map';
  let grade: '7H' | '8H' = '7H';
  let belt: BeltId = 'white';
  let progress: PlayerProgress;
  let exerciseIndex = 0;
  let answer = '';
  let orderList: string[] = [];
  let feedback = '';
  let correct = false;
  let usedHelp = false;
  let helpOpen = false;
  let tableOpen = false;
  let flashDone = false;
  let bossHp = 3;
  let selectedBossExercise: Exercise | null = null;
  let playerX = 10;
  let playerY = 83;
  let mapFocused = false;

  $: current = getContent(grade, belt);
  $: exercises = current?.exercises ?? [];
  $: exercise = exercises[exerciseIndex] ?? null;
  $: level = progress ? levelFromXp(progress.xp) : 1;
  $: xpPercent = progress ? progressPercent(progress.xp) : 0;
  $: currentKey = beltKey(grade, belt);
  $: currentProgress = progress?.belts[currentKey];
  $: if (exercise?.type === 'order' && orderList.length === 0) orderList = [...(exercise.items ?? [])];

  function movePlayer(dx: number, dy: number) {
    if (screen !== 'map') return;
    playerX = Math.max(4, Math.min(94, playerX + dx));
    playerY = Math.max(8, Math.min(90, playerY + dy));
    mapFocused = true;
  }

  function handleMapKeydown(event: KeyboardEvent) {
    if (screen !== 'map') return;
    const key = event.key.toLowerCase();
    const keys: Record<string, [number, number]> = {
      arrowleft: [-2.5, 0], a: [-2.5, 0],
      arrowright: [2.5, 0], d: [2.5, 0],
      arrowup: [0, -2.5], w: [0, -2.5], z: [0, -2.5],
      arrowdown: [0, 2.5], s: [0, 2.5]
    };
    const delta = keys[key];
    if (!delta) return;
    event.preventDefault();
    movePlayer(delta[0], delta[1]);
  }

  onMount(() => {
    progress = loadProgress();
    ready = true;
    window.addEventListener('keydown', handleMapKeydown);
    return () => window.removeEventListener('keydown', handleMapKeydown);
  });

  function selectGrade(next: '7H' | '8H') {
    grade = next;
    belt = 'white';
  }

  function openZone(next: BeltId) {
    belt = next;
    screen = 'zone';
    exerciseIndex = 0;
    answer = '';
    orderList = [];
    feedback = '';
    flashDone = false;
    helpOpen = false;
    usedHelp = false;
  }

  function startLesson() {
    screen = 'lesson';
  }

  function startPractice() {
    screen = 'practice';
    exerciseIndex = 0;
    answer = '';
    orderList = exercise?.items ? [...exercise.items] : [];
    feedback = '';
    usedHelp = false;
  }

  function addXp() {
    const gain = xpForAnswer(usedHelp);
    progress.xp += gain;
    progress.level = levelFromXp(progress.xp);
    saveProgress(progress);
  }

  function success(message = 'Bravo !') {
    correct = true;
    feedback = message;
    addXp();
  }

  function fail(message = 'Pas encore. Regarde l’aide et réessaie.') {
    correct = false;
    feedback = message;
  }

  function answerFlash(index: number) {
    if (!current) return;
    if (index === current.flashCheck.expectedIndex) {
      flashDone = true;
      success('⚡ Question flash réussie !');
      setTimeout(() => {
        feedback = '';
        startPractice();
      }, 650);
    } else {
      fail('Presque. Relis la théorie ou utilise l’aide.');
    }
  }

  function validateCurrent() {
    if (!exercise) return;

    const ok = validateExercise(exercise, answer, orderList);

    if (ok) {
      success('🎉 Bonne réponse !');
      setTimeout(() => {
        feedback = '';
        answer = '';
        usedHelp = false;

        if (exerciseIndex < exercises.length - 1) {
          exerciseIndex += 1;
          orderList = exercises[exerciseIndex]?.items ? [...(exercises[exerciseIndex].items ?? [])] : [];
        } else {
          prepareBoss();
        }
      }, 700);
    } else {
      fail('Ce n’est pas encore juste. Tu peux utiliser l’aide.');
    }
  }

  function prepareBoss() {
    bossHp = 3;
    selectedBossExercise = exercises[Math.floor(Math.random() * exercises.length)] ?? null;
    screen = 'boss';
  }

  function bossAttack() {
    if (!selectedBossExercise) return;

    const ok = validateExercise(selectedBossExercise, answer, orderList);
    if (!ok) {
      fail('Le boss bloque ton attaque. Réessaie !');
      return;
    }

    bossHp -= 1;
    success('⚔️ Coup réussi !');

    if (bossHp <= 0) {
      progress.belts[currentKey] = {
        practiceBest: Math.max(progress.belts[currentKey]?.practiceBest ?? 0, exercises.length),
        validated: true,
        bossDefeated: true
      };
      saveProgress(progress);
      setTimeout(() => {
        feedback = '';
        screen = 'final';
      }, 650);
    } else {
      setTimeout(() => {
        answer = '';
        feedback = '';
        selectedBossExercise = exercises[Math.floor(Math.random() * exercises.length)] ?? null;
      }, 650);
    }
  }

  function moveItem(from: number, to: number) {
    if (to < 0 || to >= orderList.length) return;
    const next = [...orderList];
    [next[from], next[to]] = [next[to], next[from]];
    orderList = next;
  }

  function backToMap() {
    screen = 'map';
    helpOpen = false;
    feedback = '';
  }

  function useHelp() {
    usedHelp = true;
    helpOpen = !helpOpen;
  }

  function speakCurrent() {
    if (!current) return;
  }
</script>

<svelte:head>
  <title>CONVERTIGO — Grandeurs & Mesures</title>
  <meta name="description" content="Parcours gamifié de Grandeurs et Mesures pour 7H et 8H." />
</svelte:head>

{#if !ready}
  <main class="loading"><div class="loader">↻</div><p>Chargement de Convertigo…</p></main>
{:else}
  <main class="world">
    <div class="stars"></div>

    <header class="topbar">
      <button class="logo" type="button" on:click={backToMap}>
        <span>⚡</span>
        <div><strong>CONVERTIGO</strong><small>Grandeurs & Mesures</small></div>
      </button>

      <div class="player">
        <span>NIVEAU {level}</span>
        <div class="xp"><i style={`width:${xpPercent}%`}></i></div>
        <b>{progress.xp} XP</b>
      </div>
    </header>

    {#if screen === 'map'}
      <section class="map-screen">
        <div class="intro">
          <span class="eyebrow">🗺️ MONDE LIBRE</span>
          <h1>Le Royaume des Grandeurs</h1>
          <p>Choisis une zone et pars apprendre. Pour l’instant, toutes les zones sont accessibles.</p>
          <AudioButton text="Bienvenue dans le Royaume des Grandeurs. Choisis librement une zone pour apprendre, t'entraîner et affronter son boss." label="🔊 Écouter l’introduction" />
        </div>

        <div class="grade-tabs">
          <button class:active={grade === '7H'} on:click={() => selectGrade('7H')}>7H</button>
          <button class:active={grade === '8H'} on:click={() => selectGrade('8H')}>8H</button>
        </div>

        <div class="pixel-map" aria-label={`Carte du Royaume des Grandeurs pour ${grade}`}>
          <div class="map-sky"></div><div class="map-cloud cloud-a"></div><div class="map-cloud cloud-b"></div>
          <div class="mountain mountain-a"></div><div class="mountain mountain-b"></div><div class="forest forest-a">🌲 🌲 🌲</div><div class="forest forest-b">🌲 🌲</div><div class="river"></div>
          <div class="pixel-road road-1"></div><div class="pixel-road road-2"></div><div class="pixel-road road-3"></div><div class="pixel-road road-4"></div><div class="pixel-road road-5"></div>
          {#each belts as b, i}
            {@const item = getContent(grade, b.id)}{@const bp = progress.belts[beltKey(grade, b.id)]}
            <button class={`pixel-zone zone-${i + 1}`} style={`--accent:${b.color}`} on:click={() => openZone(b.id)} aria-label={`${b.label} : ${item?.title}`}>
              <span class="zone-shadow"></span><span class="pixel-house"><span class="house-roof"></span><span class="house-body"><i></i><b></b></span><span class="house-sign">{b.icon}</span></span>
              <span class="zone-label"><strong>{b.label}</strong><small>{item?.title}</small>{#if bp?.bossDefeated}<em>✓ VALIDÉE</em>{:else}<em>ENTRER →</em>{/if}</span>
            </button>
          {/each}
          <div class="pixel-castle"><div class="castle-tower left"></div><div class="castle-main"><span>⚔</span></div><div class="castle-tower right"></div><strong>CHÂTEAU DU GRAND TEST</strong><small>ZONE FINALE · BIENTÔT</small></div>
          <div
            class="player-marker"
            class:focused={mapFocused}
            style={`left:${playerX}%;top:${playerY}%;`}
            aria-label="Ton personnage"
          >🧙</div>
          <div class="map-compass">N<br /><span>▲</span></div>
          <div class="map-legend"><span>🧙</span> Ton aventure <span>🏠</span> Zone <span>🏰</span> Grand test</div>

          <div class="map-controls" aria-label="Contrôles de déplacement">
            <div class="dpad">
              <button aria-label="Monter" on:click={() => movePlayer(0, -2.5)}>▲</button>
              <button aria-label="Aller à gauche" on:click={() => movePlayer(-2.5, 0)}>◀</button>
              <button aria-label="Aller à droite" on:click={() => movePlayer(2.5, 0)}>▶</button>
              <button aria-label="Descendre" on:click={() => movePlayer(0, 2.5)}>▼</button>
            </div>
            <span>Déplace-toi avec les flèches, WASD ou ZQSD</span>
          </div>
        </div>

        <div class="map-note">
          <span>💡</span>
          <div><strong>Parcours libre</strong><br /><small>Le déblocage des zones pourra être activé plus tard sans refaire l’architecture.</small></div>
        </div>
      </section>

    {:else if screen === 'zone'}
      <section class="zone-screen">
        {#if current}
          <button class="back" on:click={backToMap}>← Carte</button>

          <div class="zone-hero" style={`--accent:${current.color}`}>
            <div class="zone-icon">{current.icon}</div>
            <div>
              <span>{grade} · {belt.toUpperCase()}</span>
              <h1>{current.title}</h1>
              <p>{current.zone}</p>
            </div>
          </div>

          <div class="objective-card">
            <div><span class="eyebrow">🎯 OBJECTIFS</span><h2>Ce que tu vas apprendre</h2></div>
            <AudioButton text={current.objectives.join('. ')} />
            <ul>{#each current.objectives as objective}<li>{objective}</li>{/each}</ul>
          </div>

          <div class="mission-grid">
            <button class="mission theory-mission" on:click={startLesson}>
              <span>📚</span><strong>APPRENDRE</strong><small>Théorie + animation + audio</small>
            </button>
            <button class="mission practice-mission" on:click={startPractice}>
              <span>🎯</span><strong>S’ENTRAÎNER</strong><small>{exercises.length} exercices de validation</small>
            </button>
            <button class="mission boss-mission" on:click={prepareBoss}>
              <span>👹</span><strong>BOSS</strong><small>Défi final de la zone</small>
            </button>
          </div>

          <div class="tool-row">
            <button on:click={() => tableOpen = true}>📊 Tableau de conversion</button>
            <span>🎧 Audio disponible sur les consignes</span>
          </div>
        {/if}
      </section>

    {:else if screen === 'lesson' && current}
      <section class="lesson-screen">
        <button class="back" on:click={() => screen = 'zone'}>← Zone</button>

        <div class="lesson-card">
          <span class="eyebrow">📚 ÉTAPE 1 · APPRENDRE</span>
          <div class="lesson-title">
            <span class="big-icon">{current.theory.animation === 'length' ? '📏' : current.icon}</span>
            <div><h1>{current.theory.title}</h1><p>{current.theory.text}</p></div>
          </div>

          <AudioButton text={current.theory.audioText} label="🔊 Écouter la théorie" />

          <div class="learning-animation">
            {#if current.theory.animation === 'length'}
              <div class="length-animation">
                {#each ['km','hm','dam','m','dm','cm','mm'] as u, i}<div class:focus-unit={u === 'm'} style={`--delay:${i * 0.08}s`}>{u}<small>{i < 3 ? '←' : '→'}</small></div>{/each}
              </div>
              <b>Une colonne = ×10 → · ÷10 ←</b>
            {:else if current.theory.animation === 'area'}
              <div class="area-animation"><div class="grid-square"></div><strong>surface = longueur × largeur</strong></div>
            {:else if current.theory.animation === 'volume'}
              <div class="volume-animation"><div class="cube"></div><strong>volume = L × l × h</strong></div>
            {:else if current.theory.animation === 'angle'}
              <div class="angle-animation">◢ <strong>degrés = mesure de l’ouverture</strong></div>
            {:else}
              <div class="generic-animation">{current.icon}<strong>Observe, mesure, compare.</strong></div>
            {/if}
          </div>

          <div class="lesson-actions">
            <button class="help-button" on:click={useHelp}>💡 Aide</button>
            <button class="primary" on:click={() => screen = 'flash'}>J’AI COMPRIS → QUESTION FLASH</button>
          </div>

          {#if helpOpen}
            <HelpPanel text={current.theory.text} animation={current.theory.animation} close={() => helpOpen = false} />
          {/if}
        </div>
      </section>

    {:else if screen === 'flash' && current}
      <section class="challenge-screen">
        <button class="back" on:click={() => screen = 'lesson'}>← Théorie</button>
        <div class="challenge-card">
          <span class="eyebrow">⚡ QUESTION FLASH</span>
          <h1>{current.flashCheck.question}</h1>
          <AudioButton text={current.flashCheck.audioText} />
          <div class="options">
            {#each current.flashCheck.options as option, i}
              <button class:wrong={feedback && !correct && false} on:click={() => answerFlash(i)}>{option}</button>
            {/each}
          </div>
          {#if feedback}<div class:good={correct} class:error={!correct} class="feedback">{feedback}</div>{/if}
        </div>
      </section>

    {:else if screen === 'practice' && current && exercise}
      <section class="practice-screen">
        <div class="practice-top">
          <button class="back" on:click={() => screen = 'zone'}>← Zone</button>
          <span>EXERCICE {exerciseIndex + 1} / {exercises.length}</span>
          <button class="table-button" on:click={() => tableOpen = true}>📊 Tableau</button>
        </div>

        <div class="exercise-card">
          <div class="exercise-head">
            <span class="eyebrow">🎯 VALIDATION</span>
            <AudioButton text={exercise.audioText ?? exercise.instruction} />
          </div>

          <h1>{exercise.instruction}</h1>

          {#if exercise.type === 'conversion'}
            <div class="equation">{exercise.givenValue} {exercise.givenUnit} <b>= ?</b> {exercise.targetUnit}</div>
            <input bind:value={answer} on:keydown={(e) => e.key === 'Enter' && validateCurrent()} placeholder="Ta réponse…" inputmode="decimal" autofocus />
          {:else if exercise.type === 'number'}
            <input bind:value={answer} on:keydown={(e) => e.key === 'Enter' && validateCurrent()} placeholder="Ta réponse…" inputmode="decimal" autofocus />
          {:else if exercise.type === 'choice' || exercise.type === 'classification'}
            <div class="choice-grid">
              {#each exercise.options ?? [] as option}
                <button class:selected={answer === option} on:click={() => answer = option}>{option}</button>
              {/each}
            </div>
          {:else if exercise.type === 'order'}
            <div class="order-list">
              {#each orderList as item, i}
                <div class="order-item"><b>{i + 1}</b><span>{item}</span><button disabled={i === 0} on:click={() => moveItem(i,i-1)}>↑</button><button disabled={i === orderList.length-1} on:click={() => moveItem(i,i+1)}>↓</button></div>
              {/each}
            </div>
          {/if}

          <div class="exercise-tools">
            <button class="help-button" on:click={useHelp}>💡 Aide</button>
            <button class="primary" on:click={validateCurrent}>VALIDER</button>
          </div>

          {#if helpOpen}
            <HelpPanel text={exercise.helpText ?? exercise.hint} animation={current.theory.animation} close={() => helpOpen = false} />
          {/if}

          {#if feedback}<div class:good={correct} class:error={!correct} class="feedback">{feedback}</div>{/if}
        </div>
      </section>

    {:else if screen === 'boss' && current && selectedBossExercise}
      <section class="boss-screen">
        <div class="boss-header">
          <button class="back" on:click={() => screen = 'zone'}>← Zone</button>
          <span>BOSS · {current.boss.name}</span>
          <button class="table-button" on:click={() => tableOpen = true}>📊</button>
        </div>

        <div class="boss-card">
          <div class="boss-avatar">{current.boss.icon}</div>
          <h1>{current.boss.name}</h1>
          <p>{current.boss.intro}</p>
          <div class="hearts">{#each Array(bossHp) as _}❤️{/each}</div>

          <div class="boss-question">
            <AudioButton text={selectedBossExercise.audioText ?? selectedBossExercise.instruction} />
            <h2>{selectedBossExercise.instruction}</h2>

            {#if selectedBossExercise.type === 'conversion' || selectedBossExercise.type === 'number'}
              {#if selectedBossExercise.type === 'conversion'}<div class="equation">{selectedBossExercise.givenValue} {selectedBossExercise.givenUnit} <b>= ?</b> {selectedBossExercise.targetUnit}</div>{/if}
              <input bind:value={answer} placeholder="Ta réponse…" inputmode="decimal" />
            {:else}
              <div class="choice-grid">
                {#each selectedBossExercise.options ?? [] as option}
                  <button class:selected={answer === option} on:click={() => answer = option}>{option}</button>
                {/each}
              </div>
            {/if}

            <div class="boss-actions">
              <button class="help-button" on:click={useHelp}>💡 Aide</button>
              <button class="attack" on:click={bossAttack}>⚔️ ATTAQUER !</button>
            </div>

            {#if helpOpen}<HelpPanel text={selectedBossExercise.helpText ?? selectedBossExercise.hint} animation={current.theory.animation} close={() => helpOpen = false} />{/if}
            {#if feedback}<div class:good={correct} class:error={!correct} class="feedback">{feedback}</div>{/if}
          </div>
        </div>
      </section>

    {:else if screen === 'final'}
      <section class="final-screen">
        <div class="victory">🏆</div>
        <span class="eyebrow">ZONE VALIDÉE</span>
        <h1>Ceinture réussie !</h1>
        <p>{current?.title} est validé pour {grade}.</p>
        <div class="final-actions">
          <button class="primary" on:click={backToMap}>RETOURNER À LA CARTE</button>
          <button class="secondary" on:click={() => screen = 'zone'}>REJOUER LA ZONE</button>
        </div>
      </section>
    {/if}

    <footer>CONVERTIGO · Grandeurs & Mesures · Parcours libre</footer>
  </main>
{/if}

<ConversionTable bind:open={tableOpen} close={() => tableOpen = false} />

<style>
  :global(*){box-sizing:border-box}
  :global(body){margin:0;background:#050816;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#f8fafc}
  button,input{font:inherit}
  button{touch-action:manipulation}
  .world{min-height:100vh;position:relative;overflow:hidden;background:radial-gradient(circle at 20% 0%,#172554 0,#050816 45%,#020617 100%);padding-bottom:3rem}
  .stars{position:fixed;inset:0;pointer-events:none;opacity:.25;background-image:radial-gradient(#fff 1px,transparent 1px);background-size:46px 46px}
  .topbar{position:sticky;top:0;z-index:20;display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:.8rem max(1rem,calc((100vw - 1050px)/2));background:rgba(2,6,23,.82);backdrop-filter:blur(14px);border-bottom:1px solid rgba(255,255,255,.1)}
  .logo{display:flex;align-items:center;gap:.65rem;background:none;border:0;color:#fff;text-align:left;cursor:pointer}
  .logo>span{font-size:1.8rem}.logo strong{display:block;letter-spacing:.08em}.logo small{display:block;color:#94a3b8;font-size:.65rem}
  .player{display:flex;align-items:center;gap:.5rem;font-size:.7rem;font-weight:900}.player>b{color:#38bdf8}.xp{width:90px;height:7px;background:#1e293b;border-radius:99px;overflow:hidden}.xp i{display:block;height:100%;background:linear-gradient(90deg,#22d3ee,#8b5cf6)}
  .map-screen,.zone-screen,.lesson-screen,.challenge-screen,.practice-screen,.boss-screen,.final-screen{width:min(1000px,calc(100% - 2rem));margin:0 auto;padding:2rem 0}
  .intro{text-align:center;padding:2rem 0 1rem}.eyebrow{font-size:.68rem;font-weight:1000;letter-spacing:.12em;color:#38bdf8}.intro h1{font-size:clamp(2rem,5vw,3.3rem);margin:.4rem 0}.intro p{color:#94a3b8;max-width:650px;margin:0 auto 1rem;line-height:1.5}
  .grade-tabs{display:flex;justify-content:center;gap:.5rem;margin:1rem 0 2rem}.grade-tabs button{border:2px solid #334155;background:#0f172a;color:#cbd5e1;border-radius:12px;padding:.65rem 1.5rem;font-weight:1000;cursor:pointer}.grade-tabs button.active{background:#38bdf8;color:#020617;border-color:#67e8f9}
  .pixel-map{position:relative;isolation:isolate;min-height:680px;overflow:hidden;border:6px solid #111827;border-radius:22px;background:#7bc96f;box-shadow:0 18px 0 #0b1020,0 28px 55px rgba(0,0,0,.45);image-rendering:pixelated}.map-sky{position:absolute;inset:0 0 42%;background:linear-gradient(#65b8e8 0 72%,#82c86f 72%);z-index:-5}.pixel-map:before{content:"";position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px);background-size:16px 16px;pointer-events:none;z-index:10}.map-cloud{position:absolute;width:92px;height:28px;background:#f5fbff;opacity:.72;border-radius:6px;box-shadow:16px -12px 0 #f5fbff,38px -5px 0 #f5fbff,55px 5px 0 #f5fbff}.cloud-a{top:70px;left:12%}.cloud-b{top:125px;right:12%;transform:scale(.72)}.mountain{position:absolute;bottom:45%;width:0;height:0;border-left:100px solid transparent;border-right:100px solid transparent;border-bottom:150px solid #557b67;filter:drop-shadow(8px 10px 0 #456653);z-index:-3}.mountain-a{left:5%}.mountain-b{right:2%;transform:scale(.72)}.forest{position:absolute;color:#245c3a;font-size:2rem;letter-spacing:-.35rem;z-index:-1;text-shadow:4px 4px 0 rgba(16,55,38,.35)}.forest-a{left:3%;top:45%}.forest-b{right:5%;bottom:24%}.river{position:absolute;right:8%;top:33%;width:80px;height:67%;background:#46a9d9;clip-path:polygon(35% 0,80% 12%,35% 24%,75% 37%,28% 52%,70% 68%,25% 83%,58% 100%,5% 100%,20% 83%,8% 68%,25% 52%,5% 37%,27% 24%,0 12%);opacity:.8;z-index:-2}.pixel-road{position:absolute;background:#d8b46b;border:4px solid #9a7440;box-shadow:inset 0 0 0 3px rgba(255,239,174,.22);z-index:-1}.road-1{width:16px;height:210px;left:48%;top:18%;transform:rotate(17deg)}.road-2{width:260px;height:16px;left:23%;top:45%;transform:rotate(-12deg)}.road-3{width:230px;height:16px;left:38%;top:65%;transform:rotate(8deg)}.road-4{width:16px;height:190px;left:33%;top:52%;transform:rotate(-22deg)}.road-5{width:16px;height:190px;left:67%;top:42%;transform:rotate(26deg)}.pixel-zone{position:absolute;z-index:4;width:150px;border:0;background:none;color:#fff;padding:0;cursor:pointer;transform:translate(-50%,-50%);font-family:inherit}.zone-1{left:18%;top:30%}.zone-2{left:43%;top:24%}.zone-3{left:68%;top:38%}.zone-4{left:50%;top:58%}.zone-5{left:27%;top:73%}.pixel-zone:hover{z-index:8;filter:brightness(1.12)}.pixel-zone:focus-visible{outline:4px solid #fff;outline-offset:5px;border-radius:8px}.zone-shadow{position:absolute;left:50%;bottom:34px;width:104px;height:18px;transform:translateX(-50%);background:rgba(20,42,26,.32);border-radius:50%;filter:blur(1px)}.pixel-house{display:block;position:relative;width:92px;height:88px;margin:0 auto}.house-roof{position:absolute;left:7px;top:0;width:78px;height:44px;background:var(--accent);border:5px solid #392d35;clip-path:polygon(50% 0,100% 72%,92% 100%,8% 100%,0 72%);box-shadow:inset 0 -7px 0 rgba(0,0,0,.16)}.house-body{position:absolute;left:17px;top:35px;width:58px;height:48px;background:#d7c19a;border:5px solid #392d35;box-shadow:inset 0 -8px 0 rgba(90,61,42,.12)}.house-body i{position:absolute;left:9px;bottom:0;width:18px;height:29px;background:#5d3b35;border:4px solid #392d35}.house-body b{position:absolute;right:8px;top:9px;width:17px;height:16px;background:#9de3ed;border:4px solid #392d35}.house-sign{position:absolute;right:0;top:38px;width:25px;height:25px;display:grid;place-items:center;background:#f8e5aa;border:3px solid #392d35;color:#111;font-size:.8rem}.zone-label{display:flex;flex-direction:column;gap:2px;align-items:center;margin-top:2px;text-shadow:2px 2px 0 #111827}.zone-label strong{font-size:.85rem;letter-spacing:.08em}.zone-label small{font-size:.62rem;color:#e5e7eb;max-width:145px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.zone-label em{font-style:normal;font-size:.56rem;color:#fde68a;font-weight:1000;opacity:.9}.pixel-castle{position:absolute;left:50%;bottom:16px;transform:translateX(-50%);width:250px;height:120px;display:flex;align-items:flex-end;justify-content:center;z-index:5;filter:drop-shadow(5px 7px 0 rgba(20,25,40,.4))}.castle-main{width:110px;height:82px;background:#8b91a3;border:6px solid #343746;display:grid;place-items:center;color:#fef3c7;font-size:2rem}.castle-tower{width:45px;height:98px;background:#747a8d;border:6px solid #343746;position:relative}.castle-tower:before{content:"";position:absolute;left:-7px;top:-30px;width:47px;height:35px;background:#555b6d;clip-path:polygon(0 100%,0 30%,20% 30%,20% 0,40% 30%,60% 0,80% 30%,100% 30%,100% 100%)}.pixel-castle strong{position:absolute;bottom:-1px;white-space:nowrap;background:#171a26;border:3px solid #343746;padding:4px 8px;font-size:.62rem;letter-spacing:.05em}.pixel-castle small{position:absolute;bottom:-23px;color:#cbd5e1;font-size:.55rem}.player-marker{position:absolute;left:10%;bottom:13%;font-size:2rem;z-index:6;animation:playerBob 1s steps(2,end) infinite;filter:drop-shadow(3px 4px 0 #253041)}.map-controls{position:absolute;right:14px;bottom:14px;z-index:12;display:flex;flex-direction:column;align-items:flex-end;gap:6px}.map-controls>span{font-size:.55rem;color:#f8fafc;background:rgba(17,24,39,.88);border:2px solid #374151;padding:5px 7px;max-width:190px;text-align:right}.dpad{display:grid;grid-template-columns:42px 42px 42px;grid-template-rows:42px 42px;gap:4px}.dpad button{border:3px solid #343746;background:#171a26;color:#fff;font-size:1rem;font-weight:1000;cursor:pointer;box-shadow:3px 3px 0 #0b1020}.dpad button:first-child{grid-column:2}.dpad button:nth-child(2){grid-column:1;grid-row:2}.dpad button:nth-child(3){grid-column:3;grid-row:2}.dpad button:nth-child(4){grid-column:2;grid-row:2}.player-marker{transition:left .12s linear,top .12s linear}.player-marker.focused{filter:drop-shadow(0 0 5px #facc15) drop-shadow(3px 4px 0 #253041)}
.map-compass{position:absolute;right:16px;top:16px;background:#111827;border:4px solid #374151;color:#f9fafb;padding:6px 10px;text-align:center;font-size:.65rem;font-weight:1000;z-index:8}.map-compass span{color:#facc15}.map-legend{position:absolute;left:14px;top:14px;z-index:8;background:rgba(17,24,39,.88);border:3px solid #374151;color:#d1d5db;padding:7px 10px;font-size:.58rem;display:flex;gap:8px;align-items:center;flex-wrap:wrap;max-width:310px}.map-legend span{font-size:.8rem}
  .map-note{display:flex;gap:.8rem;align-items:center;margin:2rem auto 0;max-width:700px;background:rgba(56,189,248,.08);border:1px solid rgba(56,189,248,.2);border-radius:14px;padding:1rem;color:#cbd5e1}.map-note>span{font-size:1.4rem}.map-note small{color:#94a3b8}
  .back{border:1px solid #334155;background:#0f172a;color:#cbd5e1;border-radius:10px;padding:.5rem .8rem;font-weight:800;cursor:pointer;margin-bottom:1rem}
  .zone-hero{display:flex;align-items:center;gap:1rem;padding:1.4rem;border:2px solid color-mix(in srgb,var(--accent),white 10%);background:rgba(15,23,42,.8);border-radius:20px}.zone-icon{font-size:3rem}.zone-hero span{font-size:.7rem;color:var(--accent);font-weight:1000}.zone-hero h1{margin:.2rem 0;font-size:2rem}.zone-hero p{margin:0;color:#94a3b8}
  .objective-card,.lesson-card,.challenge-card,.exercise-card,.boss-card{background:rgba(15,23,42,.92);border:1px solid rgba(255,255,255,.1);border-radius:22px;padding:1.4rem;margin-top:1rem;box-shadow:0 15px 50px rgba(0,0,0,.25)}.objective-card{display:grid;grid-template-columns:1fr auto;gap:.5rem 1rem}.objective-card h2{margin:.2rem 0}.objective-card ul{grid-column:1/-1;margin:.5rem 0 0;padding-left:1.2rem;color:#cbd5e1;line-height:1.7}
  .mission-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-top:1rem}.mission{border:2px solid #334155;background:#0f172a;color:#fff;border-radius:18px;padding:1.2rem;text-align:left;cursor:pointer;display:flex;flex-direction:column;gap:.4rem;min-height:145px}.mission span{font-size:2rem}.mission strong{font-size:1rem}.mission small{color:#94a3b8;line-height:1.4}.mission:hover{border-color:#38bdf8}.tool-row{display:flex;justify-content:space-between;gap:1rem;align-items:center;margin-top:1rem;color:#64748b;font-size:.8rem}.tool-row button,.table-button{border:1px solid #334155;background:#0f172a;color:#cbd5e1;border-radius:9px;padding:.55rem .7rem;font-weight:800;cursor:pointer}
  .lesson-card,.challenge-card{max-width:760px;margin:0 auto}.lesson-title{display:flex;gap:1rem;align-items:flex-start;margin:1rem 0}.big-icon{font-size:3rem}.lesson-title h1{margin:0 0 .4rem;font-size:1.8rem}.lesson-title p{margin:0;color:#cbd5e1;line-height:1.6}.learning-animation{margin:1.5rem 0;padding:1rem;border-radius:16px;background:#020617;border:1px solid #1e293b;min-height:150px;display:grid;place-items:center;text-align:center}.length-animation{display:grid;grid-template-columns:repeat(7,1fr);width:100%;max-width:620px}.length-animation div{padding:.8rem .2rem;border-right:1px solid #334155;color:#94a3b8;font-weight:900;animation:unitIn .8s both;animation-delay:var(--delay)}.length-animation div:last-child{border:0}.length-animation .focus-unit{background:#38bdf8;color:#020617;border-radius:8px}.length-animation small{display:block;font-size:.6rem;margin-top:.3rem}.area-animation,.volume-animation,.angle-animation,.generic-animation{display:flex;align-items:center;justify-content:center;gap:1rem;flex-direction:column;color:#cbd5e1}.grid-square{width:100px;height:100px;border:4px solid #a78bfa;background:repeating-linear-gradient(0deg,transparent 0 19px,rgba(167,139,250,.3) 20px),repeating-linear-gradient(90deg,transparent 0 19px,rgba(167,139,250,.3) 20px);animation:grow 1.3s infinite alternate}.cube{width:70px;height:70px;background:#8b5cf6;transform:rotate(30deg) skew(-8deg);animation:float 1.5s infinite alternate}.angle-animation{font-size:4rem}.angle-animation strong{font-size:1rem}.generic-animation{font-size:4rem}
  .lesson-actions,.exercise-tools,.boss-actions{display:flex;gap:.7rem;justify-content:flex-end;flex-wrap:wrap}.primary,.attack,.help-button,.secondary{border:2px solid #0f172a;border-radius:11px;padding:.7rem 1rem;font-weight:1000;cursor:pointer}.primary{background:#22c55e;color:#052e16}.attack{background:#ef4444;color:#fff}.help-button{background:#fef3c7;color:#78350f}.secondary{background:#334155;color:#fff}
  .challenge-card h1{text-align:center;margin:1rem 0 1.5rem}.options,.choice-grid{display:grid;gap:.7rem}.options button,.choice-grid button{border:2px solid #334155;background:#0f172a;color:#f8fafc;border-radius:12px;padding:.85rem;text-align:left;font-weight:900;cursor:pointer}.options button:hover,.choice-grid button.selected{border-color:#38bdf8;background:#082f49}
  .feedback{margin-top:1rem;border-radius:10px;padding:.7rem;text-align:center;font-weight:900}.feedback.good{background:#14532d;color:#bbf7d0}.feedback.error{background:#7f1d1d;color:#fecaca}
  .practice-top,.boss-header{display:flex;justify-content:space-between;align-items:center;gap:.7rem}.practice-top>span,.boss-header>span{font-weight:1000;color:#38bdf8;font-size:.75rem}.exercise-head{display:flex;justify-content:space-between;align-items:center;gap:1rem}.exercise-card h1{font-size:1.35rem;line-height:1.4;margin:1.2rem 0;text-align:center}.equation{background:#eef2ff;color:#0f172a;border:2px solid #6366f1;border-radius:14px;padding:1.2rem;text-align:center;font-size:1.5rem;font-weight:1000;margin-bottom:1rem}.equation b{color:#db2777}.exercise-card>input,.boss-question input{width:100%;border:2px solid #475569;background:#020617;color:#fff;border-radius:12px;padding:.85rem;text-align:center;font-size:1.15rem;outline:none}.choice-grid{grid-template-columns:repeat(2,1fr)}.order-list{display:flex;flex-direction:column;gap:.5rem}.order-item{display:grid;grid-template-columns:35px 1fr 40px 40px;align-items:center;gap:.4rem;background:#020617;border:1px solid #334155;border-radius:10px;padding:.5rem}.order-item b{color:#38bdf8}.order-item button{border:1px solid #475569;background:#1e293b;color:#fff;border-radius:7px;padding:.4rem;cursor:pointer}.order-item button:disabled{opacity:.3}
  .boss-card{text-align:center;max-width:760px;margin:0 auto}.boss-avatar{font-size:5rem;animation:bob 1.5s infinite alternate}.boss-card h1{margin:.3rem 0}.boss-card p{color:#94a3b8}.hearts{font-size:1.4rem;margin:1rem}.boss-question{margin-top:1rem;background:#020617;border-radius:16px;padding:1rem;text-align:left}.boss-question h2{font-size:1.05rem;line-height:1.4}.boss-actions{margin-top:1rem}
  .final-screen{text-align:center;display:grid;place-items:center;min-height:70vh}.victory{font-size:7rem;animation:pop .8s}.final-screen h1{font-size:2.5rem;margin:.3rem 0}.final-screen p{color:#94a3b8}.final-actions{display:flex;gap:.7rem;flex-wrap:wrap;justify-content:center}
  footer{text-align:center;color:#334155;font-size:.7rem;padding:2rem}
  .loading{min-height:100vh;display:grid;place-items:center;background:#020617;color:#fff}.loader{font-size:3rem;animation:spin 1s linear infinite}
  @keyframes spin{to{transform:rotate(360deg)}}@keyframes playerBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}@keyframes unitIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}@keyframes grow{to{transform:scale(1.08)}}@keyframes float{to{transform:rotate(30deg) translateY(-7px)}}@keyframes bob{to{transform:translateY(-8px)}}@keyframes pop{0%{transform:scale(.5);opacity:0}70%{transform:scale(1.15)}100%{transform:scale(1)}}
  @media(max-width:720px){.map-controls>span{display:none}.dpad{transform:scale(.9);transform-origin:bottom right}.mission-grid{grid-template-columns:1fr}.objective-card{grid-template-columns:1fr}.zone-hero{align-items:flex-start}.choice-grid{grid-template-columns:1fr}.topbar{align-items:flex-start}.player{flex-direction:column;align-items:flex-end}.xp{width:65px}.tool-row{align-items:flex-start;flex-direction:column}.map-screen,.zone-screen,.lesson-screen,.challenge-screen,.practice-screen,.boss-screen,.final-screen{width:min(100% - 1rem,1000px)}}
  @media(prefers-reduced-motion:reduce){*,*:before,*:after{animation:none!important;transition:none!important}}
</style>
