<script lang="ts">
  export let open = false;
  export let close: () => void = () => {};
</script>

{#if open}
  <div class="overlay" role="presentation" on:click={close}>
    <section class="table-card" role="dialog" aria-modal="true" aria-label="Tableau de conversion" on:click|stopPropagation>
      <div class="top">
        <div>
          <span class="eyebrow">OUTIL D'AIDE</span>
          <h2>📊 Tableau de conversion</h2>
          <p>Chaque déplacement d’une colonne correspond à ×10 ou ÷10.</p>
        </div>
        <button class="close" type="button" on:click={close}>✕</button>
      </div>

      <div class="conversion-grid">
        {#each ['km','hm','dam','m','dm','cm','mm'] as unit}
          <div class="unit">{unit}</div>
        {/each}
      </div>

      <div class="arrow-row">
        <span>← ÷10</span>
        <strong>UNITÉ DE DÉPART</strong>
        <span>×10 →</span>
      </div>

      <div class="examples">
        <div><b>m → cm</b><span>2 colonnes → ×100</span></div>
        <div><b>km → m</b><span>3 colonnes → ×1000</span></div>
        <div><b>cm → m</b><span>2 colonnes ← ÷100</span></div>
      </div>

      <button class="close-bottom" type="button" on:click={close}>J'AI COMPRIS</button>
    </section>
  </div>
{/if}

<style>
  .overlay { position:fixed; inset:0; z-index:100; background:rgba(2,6,23,.72); display:grid; place-items:center; padding:1rem; }
  .table-card { width:min(680px,100%); background:#fff; color:#0f172a; border:4px solid #0f172a; border-radius:24px; padding:1.25rem; box-shadow:0 10px 0 #0f172a; }
  .top { display:flex; justify-content:space-between; gap:1rem; }
  .eyebrow { font-size:.7rem; font-weight:900; color:#6366f1; }
  h2 { margin:.2rem 0; font-size:1.35rem; }
  p { margin:0; color:#475569; font-weight:600; }
  .close { border:3px solid #0f172a; background:#f87171; color:#fff; border-radius:10px; font-weight:900; cursor:pointer; width:40px; height:40px; }
  .conversion-grid { display:grid; grid-template-columns:repeat(7,1fr); gap:4px; background:#0f172a; padding:4px; border-radius:14px; margin:1.2rem 0 .7rem; }
  .unit { text-align:center; padding:.75rem .2rem; background:#38bdf8; border-radius:8px; font-weight:1000; }
  .arrow-row { display:flex; justify-content:space-between; gap:.5rem; font-size:.75rem; font-weight:900; color:#475569; }
  .examples { display:grid; grid-template-columns:repeat(3,1fr); gap:.6rem; margin:1rem 0; }
  .examples div { background:#eef2ff; border:2px solid #c7d2fe; border-radius:12px; padding:.7rem; display:flex; flex-direction:column; gap:.25rem; }
  .examples span { font-size:.75rem; color:#475569; }
  .close-bottom { width:100%; border:3px solid #0f172a; background:#22c55e; color:#0f172a; border-radius:12px; padding:.75rem; font-weight:1000; cursor:pointer; }
  @media(max-width:560px){ .examples{grid-template-columns:1fr}.conversion-grid{gap:2px}.unit{font-size:.8rem} }
</style>
